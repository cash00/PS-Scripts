#
# Copyright (C) Microsoft. All rights reserved.
#

$defaultInstallationPath = $env:ProgramFiles + '\RemoteDesktopWeb'
$configKeyPath = 'HKLM:\Software\Microsoft\RemoteDesktopWeb'
$installedPathValueName = 'InstalledPath'
$managementToolsVersionName = 'ManagementToolsVersion'
$suppressTelemetryValueName = 'SuppressTelemetry'
$internalDirName = 'Internal'
$clientDirName = 'Clients'
$packageTempDirName = 'Temp'
$configDataDirName = 'Config'
$prodClientVdirName = 'webclient'
$testClientVdirName = 'webclient-test'
$everybodyIdentity = New-Object System.Security.Principal.SecurityIdentifier 'S-1-1-0'
$everybodyReadRule = New-Object System.Security.AccessControl.FileSystemAccessRule $everybodyIdentity,'Read','Allow'
$nobodyReadRule = New-Object System.Security.AccessControl.FileSystemAccessRule $everybodyIdentity,'Read','Deny'
$rdWebPath = '/RDWeb'
$manifestFileName = 'manifest.json'
$clientContentDirName = 'content'

[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.Web.Administration')
[System.Reflection.Assembly]::LoadWithPartialName('System.Security.Cryptography.X509Certificates')

function UpdateIISContext
    (
    $context
    )
{
    $context.IISServerManager = Get-IISServerManager
    if (!$context.IISServerManager)
    {
        Write-Error 'The IIS Server Manager could not be loaded'
        return $FALSE
    }

    $webSites = Get-IISSite
    Foreach ($site in $webSites)
    {
        $rdWebApp = $site.Applications | Where-Object {$_.Path -eq $rdWebPath } | Select-Object -First 1
        if ($rdWebApp)
        {
            $context.RdWebApplication = $rdWebApp
            $context.RdWebSite = $site

            Break
        }        
    }

    if (!$context.RdWebApplication)
    {
        Write-Error 'RD Web Access does not appear to be installed on the system.'
        return $FALSE
    }
    else
    {
        $context.ProdClientVdir = $context.RdWebApplication.VirtualDirectories | Where-Object {$_.Path -eq "/$prodClientVdirName"} | Select-Object -First 1
        $context.ProdClientConfigVdir = $context.RdWebApplication.VirtualDirectories | Where-Object {$_.Path -eq "/$prodClientVdirName/config"} | Select-Object -First 1
        $context.TestClientVdir = $context.RdWebApplication.VirtualDirectories | Where-Object {$_.Path -eq "/$testClientVdirName"} | Select-Object -First 1
        $context.TestClientConfigVdir = $context.RdWebApplication.VirtualDirectories | Where-Object {$_.Path -eq "/$testClientVdirName/config"} | Select-Object -First 1
    }

    return $TRUE
}

function EnsureDirectoryExists
    (
        [Parameter(mandatory=$true)]
        $Path,
        $AccessRule
    )
{
    $targetDir = Get-Item $Path -ErrorAction SilentlyContinue
    if (!$targetDir)
    {
        $targetDir = New-Item -Path $Path -ItemType 'directory'
        if (!$targetDir)
        {
            return $FALSE
        }

        if ($AccessRule)
        {
            $acl = Get-Acl $Path
            $acl.SetAccessRule($AccessRule)
            Set-Acl $Path $acl
        }
    }

    return $TRUE
}

function UpdateDeploymentSettingsFile
    (
    $context
    )
{
    $deploymentSettings = @{
        'deploymentType' = 'rdWeb';
        'suppressTelemetry' = $context.DeploymentSettings.SuppressTelemetry
        };

    Set-Content -Path $context.DeploymentSettingsPath ('var DeploymentSettings = ' + (ConvertTo-Json $deploymentSettings))
}

function EnsureInitialized
{
    [OutputType([Boolean])]
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='Low')]
    Param(
        $context,
        [string] $installPath
    )

    if ($env:RdWebClientManagementCatalogURL)
    {
        $context.PackageCatalogUrl = $env:RdWebClientManagementCatalogURL
    }
    else
    {
        $context.PackageCatalogUrl = 'https://go.microsoft.com/fwlink/?linkid=2005418'
    }

    if (!$installPath)
    {
        $installPath = $defaultInstallationPath
    }
    $internalDirPath = Join-Path -Path $installPath -ChildPath $internalDirName
    $context.ClientPath = Join-Path -Path $internalDirPath -ChildPath $clientDirName
    $context.PackageTempPath = Join-Path -Path $internalDirPath -ChildPath $packageTempDirName
    $context.ConfigDataPath = Join-Path -Path $internalDirPath -ChildPath $configDataDirName
    $context.BrokerCertPath = Join-Path -Path $context.ConfigDataPath -ChildPath 'brokercert.cer'
    $context.DeploymentSettingsPath = Join-Path -Path $context.ConfigDataPath -ChildPath 'deploymentSettings.js'

    $installedDir = Get-Item $installPath -ErrorAction SilentlyContinue
    if (!$installedDir)
    {
        if (!$PSCmdlet.ShouldProcess(
            "RDWebClientManagement in '$installPath'",
            'Install'))
        {
            return $false
        }
    }

    $freshInstall = $FALSE
    if (!$context.ConfigKey)
    {
        $context.ConfigKey = New-Item -Path $configKeyPath
        $context.ConfigKey.SetValue($installedPathValueName, $installPath)
        $context.ConfigKey.SetValue($suppressTelemetryValueName, $false, [Microsoft.Win32.RegistryValueKind]::DWord)
        $context.InstalledPath = $installPath
        $freshInstall = $TRUE
    }

    $lastVersionStr = $context.ConfigKey.GetValue($managementToolsVersionName)
    if (!$lastVersionStr)
    {
        $lastVersionStr = '0.8'
    }
    $lastVersion = [System.Version]$lastVersionStr

    if (!$freshInstall -and ($lastVersion -lt [System.Version]'1.0'))
    {
        Write-Error ("The web client was installed using an older version of RDWebClientManagement and " +
        "must first be removed before deploying the new version. Using the old version of " +
        "RDWebClientManagement, uninstall the web client by running 'Uninstall-RDWebClient'. " +
        "Then reinstall the web client using this new module. For more information, " +
        "visit https://go.microsoft.com/fwlink/?linkid=870181 .")
        return $FALSE
    }

    $context.ConfigKey | Set-ItemProperty -Name $managementToolsVersionName -Value $context.Version.ToString()
    
    if (!$installedDir)
    {
        Write-Warning "Initializing RDWebClientManagement in '$installPath'. To uninstall, use Uninstall-RDWebClient."
        if (!(EnsureDirectoryExists -Path $installPath))
        {
            return $FALSE
        }
    }

    if (!(EnsureDirectoryExists -Path $internalDirPath -AccessRule $nobodyReadRule))
    {
        return $FALSE
    }

    if (!(EnsureDirectoryExists -Path $context.ClientPath -AccessRule $everybodyReadRule))
    {
        return $FALSE
    }

    if (!(EnsureDirectoryExists -Path $context.PackageTempPath))
    {
        return $FALSE
    }

    if (!(EnsureDirectoryExists -Path $context.ConfigDataPath -AccessRule $everybodyReadRule))
    {
        return $FALSE
    }
    
    $context.DeploymentSettings = @{
        'SuppressTelemetry' = $false;
        }

    $disableTelemetry = $context.ConfigKey.GetValue($suppressTelemetryValueName)
    $context.DeploymentSettings.SuppressTelemetry = ($null -ne $disableTelemetry) -and ($disableTelemetry -gt 0)

    UpdateDeploymentSettingsFile $context
        
    if (!(UpdateIISContext $context))
    {
        return $FALSE
    }

    return $TRUE
}

function GetModuleContext
{
    $contextProps = @{};
    $contextProps.Version = (Get-Module RDWebClientManagement).Version
    $contextProps.ConfigKey = Get-Item $configKeyPath -ErrorAction SilentlyContinue
    [string]$contextProps.InstalledPath = $null
    [string]$contextProps.ClientPath = $null
    [string]$contextProps.PackageTempPath = $null
    [string]$contextProps.ConfigDataPath = $null
    [string]$contextProps.BrokerCertPath = $null
    [string]$contextProps.DeploymentSettingsPath = $null
    $contextProps.IISServerManager = $null
    $contextProps.RdWebApplication = $null
    $contextProps.RdWebSite = $null
    [Microsoft.Web.Administration.VirtualDirectory]$contextProps.ProdClientVdir = $null
    [Microsoft.Web.Administration.VirtualDirectory]$contextProps.ProdClientConfigVdir = $null
    [Microsoft.Web.Administration.VirtualDirectory]$contextProps.TestClientVdir = $null
    [Microsoft.Web.Administration.VirtualDirectory]$contextProps.TestClientConfigVdir = $null
    $contextProps.PackageCatalogUrl = $null
    $contextProps.DeploymentSettings = @{}


    if ($contextProps.ConfigKey)
    {
        $contextProps.InstalledPath = $contextProps.ConfigKey.GetValue($installedPathValueName)
    }

    $context = New-Object -TypeName PSObject -Property $contextProps

    return $context;
}

function CheckClientSupport
{
    Param(
        [Parameter(mandatory=$true)]
        $context,
        [Parameter(mandatory=$true)]
        $package
    )

    if (!$package.minRDWebClientManagementVersion -or ([System.Version]$package.minRDWebClientManagementVersion -gt $context.Version) )
    {
        Write-Error "The requested package cannot be installed with this version of RDWebClientManagement."
        return $FALSE
    }

    return $TRUE
}

function GetRDWebClientPackagesInternal
{
    Param(
        [Parameter(mandatory=$true)]
        $context
    )

    foreach ($clientDir in Get-ChildItem $context.ClientPath -Directory)
    {
        $clientObject = $null
        $clientObject = Get-ChildItem $clientDir.FullName $manifestFileName -File | Get-Content -ErrorAction Continue | ConvertFrom-Json -ErrorAction Continue
        if ($clientObject -and $clientObject.version)
        {
            $clientObject | Add-Member 'path' $clientDir.FullName
            $clientObject | Add-Member '_baseVersion' ([System.Version]::Parse(($clientObject.version -replace '^([0-9.]*).*$','$1')))

            Write-Output $clientObject
        }
    }
}

<#
.SYNOPSIS 
Entirely removes the Remote Desktop web client from the system, including any downloaded client packages and configured settings
#>
function Uninstall-RDWebClient
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='High')]Param()

    $context = GetModuleContext

    if (!$PSCmdlet.ShouldProcess(
        'The Remote Desktop web client, including any downloaded client packages and configured settings.',
        'Uninstall'
    ))
    {
        return
    }

    if ($context.InstalledPath)
    {
        if (UpdateIISContext $context -and $context.RdWebApplication -and $context.IISServerManager)
        {
            $confChanged = $FALSE

            if ($context.TestClientVdir)
            {
                $context.RdWebApplication.VirtualDirectories.Remove($context.TestClientVdir)
                $confChanged = $TRUE
            }

            if ($context.TestClientConfigVdir)
            {
                $context.RdWebApplication.VirtualDirectories.Remove($context.TestClientConfigVdir)
                $confChanged = $TRUE
            }
                        
            if ($context.ProdClientVdir)
            {
                $context.RdWebApplication.VirtualDirectories.Remove($context.ProdClientVdir)
                $confChanged = $TRUE
            }

            if ($context.ProdClientConfigVdir)
            {
                $context.RdWebApplication.VirtualDirectories.Remove($context.ProdClientConfigVdir)
                $confChanged = $TRUE
            }

            if ($confChanged)
            {
                $context.IISServerManager.CommitChanges()
            }
        }
        
        $internalPath = Join-Path $context.InstalledPath $internalDirName

        $acl = Get-Acl $internalPath
        $acl.RemoveAccessRule($nobodyReadRule) | Out-Null
        Set-Acl $internalPath $acl


        Get-Item $context.InstalledPath | Remove-Item -Recurse -Force
    }
    else
    {
        Write-Error 'The Remote Desktop web client is not installed.'
        return
    }

    Remove-Item $configKeyPath -ErrorAction SilentlyContinue
}

<#
.SYNOPSIS 
Finds the Remote Desktop web client packages that are available for installation

.PARAMETER RequiredVersion
Specifies the exact version of the package to find. By default, Find-RDWebClientPackage only returns the newest available version.

.PARAMETER AllVersions
Indicates that Find-RDWebClientPackage should return all available versions of the client. By default, Find-RDWebClientPackage only returns the newest available version.

.EXAMPLE
Find-RDWebClientPackage

Description
-----------
Finds the client package with the highest version

.EXAMPLE
Find-RDWebClientPackage -AllVersions

Description
-----------
Finds all available client packages

.EXAMPLE
Find-RDWebClientPackage -RequiredVersion 0.7.0

Description
-----------
Finds the client package with version number 0.7.0, if it is available
#>
function Find-RDWebClientPackage
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    [OutputType([PSCustomObject])]
    Param(
        [Parameter()]
        [string]$RequiredVersion,
        [switch]$AllVersions
    )

    $context = GetModuleContext
    if (!(EnsureInitialized $context))
    {
        return
    }

    $catalog = Invoke-RestMethod $context.PackageCatalogUrl
    if (!$catalog -or !$catalog.packages)
    {
        Write-Error 'The package catalog could not be read or was invalid.'
        return
    }
        
    $results = $catalog.packages
    if ($RequiredVersion)
    {
        $results = $results | Where-Object {$_.version -eq $RequiredVersion}
    }

    foreach ($client in $results)
    {
        if ($client.version)
        {
            $client | Add-Member '_baseVersion' ([System.Version]::Parse(($client.version -replace '^([0-9.]*).*$','$1')))
        }
    }

    $results = $results | Sort-Object packageId,_baseVersion -Descending 
        
    if (!$AllVersions)
    {
        $results = $results | Select-Object -First 1
    }

    $results 
}

<#
.SYNOPSIS 
Installs a Remote Desktop web client package locally

.PARAMETER RequiredVersion
Specifies the exact version of the package to install. If you do not add this parameter, Install-RDWebClientPackage installs the highest available version of the client.

.PARAMETER Source
File path for the RD web client package to install. The Save-RDWebClientPackage command can be used to download the RD web client package.

.EXAMPLE
Install-RDWebClientPackage

Description
-----------
Installs the client package with the highest version

.EXAMPLE
Install-RDWebClientPackage -RequiredVersion 0.7.0

Description
-----------
Installs the client package with version number 0.7.0, if it is available

.EXAMPLE
Install-RDWebClientPackage -Source c:\rdwebclientpackages\1.0.0.zip

Description
-----------
Installs the client package located at c:\rdwebclientpackages\1.0.0.zip

#>
function Install-RDWebClientPackage
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param(
        [Parameter()]
        [string]$RequiredVersion,
        [Parameter()]
        [string]$Source
    )

    $context = GetModuleContext
    $initialized = !!(EnsureInitialized $context)
    $continue = $PSCmdlet.ShouldProcess('The Remote Desktop web client package','Install')
    if (!($initialized -and $continue))
    {
        return
    }

    if ($Source)
    {
        $newClientPath = Join-Path -Path $context.ClientPath -ChildPath ([System.IO.Path]::GetRandomFileName())
        Expand-Archive $Source $newClientPath | Out-Null

        $newClientObject = Get-ChildItem $newClientPath $manifestFileName -File | Get-Content -ErrorAction Continue | ConvertFrom-Json -ErrorAction Continue
        if ($newClientObject -and $newClientObject.version)
        {
            if ($RequiredVersion -and $RequiredVersion -ne $newClientObject.version)
            {
                Write-Warning 'The requested Remote Desktop web client version was not found.'
                Remove-Item $newClientPath -Recurse -Force
                return
            }

            $clients = GetRDWebClientPackagesInternal($context)
            foreach ($client in $clients)
            {
                if ($client.version -eq $newClientObject.version -and $client.path -ne $newClientPath)
                {
                    Write-Warning 'The requested Remote Desktop web client is already installed.'
                    Remove-Item $newClientPath -Recurse -Force
                    return
                }
            }
        }
        else
        {
            Write-Warning 'The source Remote Desktop web client package is not valid.'
            Remove-Item $newClientPath -Recurse -Force
            return
        }
    }
    else
    {
        $packageObject = $null    
        if ($RequiredVersion)
        {
            $packageObject = Find-RDWebClientPackage -RequiredVersion $RequiredVersion
            if (!$packageObject)
            {
                Write-Error 'The requested Remote Desktop web client package is not available.'
                return
            }
        }
        else
        {
            $packageObject = Find-RDWebClientPackage
            if (!$packageObject)
            {
                Write-Error 'The Remote Desktop web client is not available for installation'
                return
            }
        }
        
        if (GetRDWebClientPackagesInternal $context | Where-Object {$_.version -eq $packageObject.version})
        {
            Write-Warning 'The requested Remote Desktop web client is already installed.'
            return
        }

        if (!(CheckClientSupport $context $packageObject))
        {
            return
        }

        $archiveFileName = Join-Path -Path $context.PackageTempPath -ChildPath ([System.IO.Path]::GetRandomFileName() + '.zip')
        $webclient = New-Object System.Net.WebClient
        $webclient.DownloadFile($packageObject.url, $archiveFileName);

        $newClientPath = Join-Path -Path $context.ClientPath -ChildPath ([System.IO.Path]::GetRandomFileName())
        Expand-Archive $archiveFileName $newClientPath | Out-Null
        Remove-Item $archiveFileName
    }
}

<#
.SYNOPSIS 
Saves a Remote Desktop web client package locally for installing later on same or different machine.

.PARAMETER RequiredVersion
Specifies the exact version of the package to install. If you do not add this parameter, Save-RDWebClientPackage saves the highest available version of the client.

.PARAMETER Path
Folder path for saving the web client package

.EXAMPLE

Save-RDWebClientPackage c:\rdwebclientpackages 

Description
-----------
Saves the client package with the highest version to c:\rdwebclientpackages

.EXAMPLE
Save-RDWebClientPackage c:\rdwebclientpackages -RequiredVersion 1.0.0

Description
-----------
Saves the client package with version number 1.0.0, if it is available, to c:\rdwebclientpackages directory
#>
function Save-RDWebClientPackage
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param(
        [Parameter(mandatory=$true, Position=0)]
        [string] $Path,        
        [Parameter(mandatory=$false)]
        [string]$RequiredVersion
    )

    $context = GetModuleContext
    $initialized = !!(EnsureInitialized $context)
    $continue = $PSCmdlet.ShouldProcess('The Remote Desktop web client package','Save')
    if (!($initialized -and $continue))
    {
        return
    }

    $packageObject = $null
    if ($RequiredVersion)
    {
        $packageObject = Find-RDWebClientPackage -RequiredVersion $RequiredVersion
        if (!$packageObject)
        {
            Write-Error 'The requested Remote Desktop web client package is not available.'
            return
        }
    }
    else
    {
        $packageObject = Find-RDWebClientPackage
        if (!$packageObject)
        {
            Write-Error 'The Remote Desktop web client is not available'
            return
        }
    }
    
    $archiveFileName = Join-Path -Path $Path -ChildPath ('rdwebclient-' + $packageObject.version + '.zip')
    $webclient = New-Object System.Net.WebClient
    $webclient.DownloadFile($packageObject.url, $archiveFileName);

    Write-Information "RD web client package saved '$archiveFileName'."
}

<#
.SYNOPSIS 
Returns a list of all Remote Desktop web client packages that have been installed locally
#>
function Get-RDWebClientPackage
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    [OutputType([PSCustomObject])]
    Param()

    $context = GetModuleContext
    if (!(EnsureInitialized $context))
    {
        return
    }

    $result = @()
    $clients = GetRDWebClientPackagesInternal($context)
    if ($clients)
    {
        foreach ($client in $clients)
        {
            $client | Add-Member 'publishedAs' @()
            $clientContent = Join-Path $client.path $clientContentDirName
            if ($context.TestClientVdir -and $context.TestClientVdir.PhysicalPath -eq $clientContent)
            {
                $client.publishedAs += 'Test'
            }

            if ($context.ProdClientVdir -and $context.ProdClientVdir.PhysicalPath -eq $clientContent)
            {
                $client.publishedAs += 'Production'
            }

            $result += $client
        }

        $result | Sort-Object packageId,_baseVersion -Descending
    }
    else
    {
        Write-Information 'No clients are installed.'
    }

}

<#
.SYNOPSIS 
Uninstalls a Remote Desktop web client package from this system

.PARAMETER RequiredVersion
Specifies the exact version of the package to uninstall.

.EXAMPLE
Uninstall-RDWebClientPackage -RequiredVersion 0.7.0

Description
-----------
Uninstalls the client package with version number 0.7.0, if it is available
#>
function Uninstall-RDWebClientPackage
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='Medium')]
    Param(
        [Parameter(mandatory=$true)]
        [string]$RequiredVersion
    )

    $context = GetModuleContext
    $initialized = !!(EnsureInitialized $context)
    $continue = $PSCmdlet.ShouldProcess("The Remote Desktop web client package, version '$RequiredVersion'",'Uninstall')
    if (!($initialized -and $continue))
    {
        return
    }

    $package = Get-RDWebClientPackage | Where-Object {$_.version -eq $RequiredVersion} | Select-Object -First 1
    if (!$package)
    {
        Write-Error 'The requested client package is not installed.'
        return
    }

    if ($package.publishedAs.Count -gt 0)
    {
        Write-Error 'The requested client package has been published. You must unpublish it with Unpublish-RDWebClientPackage before you can uninstall it.'
        return
    }

    Get-Item $package.path | Remove-Item -Recurse -Force
}

<#
.SYNOPSIS 
Publishes a Remote Desktop web client package through IIS

.PARAMETER Type
Indicates the type of deployment to publish as. The type must be either 'Test' or 'Production'.

If the type is 'Test', the client will be published in the "RDWeb/webclient-test" vdir.

If the type is 'Production', the client will be published in the "RDWeb/webclient" vdir.

.PARAMETER RequiredVersion
Specifies the exact version of the package to publish. 

.PARAMETER Latest
Specifies that the installed web client package with the highest version should be published. 

.EXAMPLE
Publish-RDWebClientPackage -Latest -Type Test

Description
-----------
Publishes the installed web client with the highest version number into the "RDWeb/webclient-test" vdir

.EXAMPLE
Publish-RDWebClientPackage -RequiredVersion 0.7.0 -Type Production

Description
-----------
Publishes the installed web client with version number 0.7.0 into the "RDWeb/webclient" vdir
#>
function Publish-RDWebClientPackage
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='Medium')]
    Param(
        [Parameter(mandatory=$true, Position=0)]
        [ValidateSet('Test', 'Production')]
        [string]$Type,
        [Parameter(mandatory=$true, ParameterSetName = 'RequiredVersion')]
        [string]$RequiredVersion,
        [Parameter(mandatory=$true, ParameterSetName = 'Latest')]
        [switch]$Latest
    )

    $context = GetModuleContext
    $initialized = !!(EnsureInitialized $context)
    $continue = $PSCmdlet.ShouldProcess('The Remote Desktop web client package','Publish alongside Remote Desktop Web Access')
    if (!($initialized -and $continue))
    {
        return
    }

    if (!(Get-Item -Path $context.BrokerCertPath -ErrorAction SilentlyContinue))
    {
        Write-Error 'A broker certificate must be installed before publishing a client. Use Import-RDWebClientBrokerCert.'
        return
    }

    $targetClient = $null
    if ($Latest)
    {
        $targetClient = Get-RDWebClientPackage | Sort-Object -Property version -Descending | Select-Object -First 1
    }
    elseif ($RequiredVersion)
    {
        $targetClient = Get-RDWebClientPackage | Where-Object {$_.version -eq $RequiredVersion} | Select-Object -First 1
    }

    $previouspackage = Get-RDWebClientPackage | Where-Object {$Type -in $_.publishedAs} | Select-Object -First 1

    if ($previouspackage)
    {
        if ($previouspackage.version -eq $targetClient.version)
        {
            Write-Warning 'The requested package has already been published for this client type.'
            return
        }

        Write-Warning "Replacing the previously published client package for client type '$Type' (version = $($previouspackage.version) )..."
    }

    if (!$targetClient)
    {
        Write-Error 'The requested client package is not installed.'
        return
    }
        
    if (!(CheckClientSupport $context $targetClient))
    {
        return
    }

    Write-Warning 'Using the Remote Desktop web client with per-device licensing is not supported.'
    
    [Microsoft.Web.Administration.VirtualDirectory]$targetVdir = $null
    [Microsoft.Web.Administration.VirtualDirectory]$targetConfigVdir = $null
    $targetVdirName = $null
    $targetConfigVdirPath = $null
    if ($Type -eq 'Test')
    {
        $targetVdir = $context.TestClientVdir
        $targetVdirName = $testClientVdirName
        $targetConfigVdir = $context.TestClientConfigVdir
        $targetConfigVdirPath = "/$testClientVdirName/config"
    }
    else
    {
        $targetVdir = $context.ProdClientVdir
        $targetVdirName = $prodClientVdirName
        $targetConfigVdir = $context.ProdClientConfigVdir
        $targetConfigVdirPath = "/$prodClientVdirName/config"
    }

    $clientContentPath = Join-Path $targetClient.path $clientContentDirName
    if ($targetVdir)
    {
        $targetVdir.PhysicalPath = $clientContentPath
    }
    else
    {
        $targetVdir = $context.RdWebApplication.VirtualDirectories.Add("/$targetVdirName", $clientContentPath) | Out-Null
    }

    if ($targetConfigVdir)
    {
        $targetConfigVdir.PhysicalPath = $context.ConfigDataPath
    }
    else
    {
        $targetConfigVdir = $context.RdWebApplication.VirtualDirectories.Add($targetConfigVdirPath, $context.ConfigDataPath) | Out-Null
    }

    Set-WebConfigurationProperty -PSPath "IIS:\Sites\$($context.RdWebSite)\RDWeb" -Location $targetVdirName -Filter 'system.webServer/httpRedirect' -Name '.' -Value @{enabled = 'false'}
    
    $context.IISServerManager.CommitChanges()
    UpdateIISContext($context) | Out-Null
}

<#
.SYNOPSIS 
Unpublishes a previously-published Remote Desktop web client package

.PARAMETER Type
Indicates the type of deployment to unpublish. The type must be either 'Test' or 'Production'.

If the type is 'Test', the client in the "RDWeb/webclient-test" vdir will be unpublished.

If the type is 'Production', the client in the "RDWeb/webclient" vdir will be unpublished.

.EXAMPLE
Unpublish-RDWebClientPackage -Type Production

Description
-----------
Unpublishes the currently-published production client
#>
function Unpublish-RDWebClientPackage
{
    [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='Medium')]
    Param(
        [Parameter(mandatory=$true)]
        [ValidateSet('Test', 'Production')]
        [string]$Type
    )

    $isTest = $Type -eq 'Test'

    $context = GetModuleContext
    $initialized = !!(EnsureInitialized $context)
    if ($isTest)
    {
        $vdirName = $testClientVdirName
    }
    else
    {
        $vdirName = $prodClientVdirName
    }
    $continue = $PSCmdlet.ShouldProcess("The Remote Desktop web client in '$vdirName'",'Unpublish')
    if (!($initialized -and $continue))
    {
        return
    }

    [Microsoft.Web.Administration.VirtualDirectory]$targetVdir = $null
    [Microsoft.Web.Administration.VirtualDirectory]$targetConfigVdir = $null
    if ($isTest)
    {
        $targetVdir = $context.TestClientVdir
        $targetConfigVdir =$context.TestClientConfigVdir
    }
    else
    {
        $targetVdir = $context.ProdClientVdir
        $targetConfigVdir =$context.ProdClientConfigVdir
    }

    if ($targetVdir)
    {
        $context.RdWebApplication.VirtualDirectories.Remove($targetVdir)

        if ($targetConfigVdir)
        {
            $context.RdWebApplication.VirtualDirectories.Remove($targetConfigVdir)
        }

        Remove-WebConfigurationLocation -PSPath "IIS:\Sites\$($context.RdWebSite)\RDWeb" -Name $vdirName | Out-Null

        $context.IISServerManager.CommitChanges()
    }
    else
    {
        Write-Error 'The requested client type is not published.'
    }
}

<#
.SYNOPSIS 
Imports a broker certificate file for use with the Remote Desktop web client

.PARAMETER Path
File path for the certificate file to import

.PARAMETER Password
The password to use in opening the certificate file.

.PARAMETER PromptForPassword
Indicates that Import-RDWebClientBrokerCert should interactively prompt the user for
a password to use in opening the certificate file.

.EXAMPLE
Import-RDWebClientBrokerCert brokercert.cer

Description
-----------
Imports a certificate from a .cer file

.EXAMPLE
Import-RDWebClientBrokerCert brokercert.pfx -PromptForPassword

Description
-----------
Imports a certificate from a password-protected .pfx file. An interactive prompt will be used to 
request the password that is needed to open the file.
#>
function Import-RDWebClientBrokerCert
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param(
        [Parameter(mandatory=$true, Position=0)]
        [string] $Path,
        [Parameter(mandatory=$false, ParameterSetName = 'NoPrompt')]
        [SecureString] $Password,
        [Parameter(mandatory=$true, ParameterSetName = 'WithPrompt')]
        [switch] $PromptForPassword
    )

    $context = GetModuleContext
    $initialized = !!(EnsureInitialized $context)
    $continue = $PSCmdlet.ShouldProcess('The certificate that identifies the Remote Desktop Connection Broker',
        'Import')
    if (!($initialized -and $continue))
    {
        return
    }
    
    $certificateCreateArgs = @($Path)

    $password = $Password
    if ($PromptForPassword)
    {
        $password = Read-Host -Prompt 'Password' -AsSecureString
    }

    if ($password)
    {
        $certificateCreateArgs += $password
    }

    $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 $certificateCreateArgs
    if ($cert)
    {
        [System.IO.File]::WriteAllBytes($context.BrokerCertPath, $cert.RawData)
    }
}

<#
.SYNOPSIS 
Returns information about the broker certificate that is being used by the Remote Desktop web client
#>
function Get-RDWebClientBrokerCert
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    [OutputType([System.Security.Cryptography.X509Certificates.X509Certificate2])]
    Param()

    $context = GetModuleContext
    if (!(EnsureInitialized $context))
    {
        return
    }

    if (Get-Item $context.BrokerCertPath -ErrorAction SilentlyContinue)
    {
        New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 @($context.BrokerCertPath)
    }
    else
    {
        Write-Information 'A broker certificate is not installed.'
    }
}

<#
.SYNOPSIS 
Removes the broker certificate that is being used by the Remote Desktop web client
#>
function Remove-RDWebClientBrokerCert
{
    [CmdletBinding(SupportsShouldProcess=$true)]Param()

    $context = GetModuleContext
    $initialized = !!(EnsureInitialized $context)
    $continue = $PSCmdlet.ShouldProcess('The certificate that identifies the Remote Desktop Connection Broker',
        'Remove')
    if (!($initialized -and $continue))
    {
        return
    }

    if (Get-Item $context.BrokerCertPath -ErrorAction SilentlyContinue)
    {
        Remove-Item $context.BrokerCertPath
    }
    else
    {
        Write-Information 'A broker certificate is not installed.'
    }
}

<#
.SYNOPSIS
Sets a deployment setting for the Remote Desktop web client
.PARAMETER Name
Specifies the name of the setting
.PARAMETER Value
The new value for the setting
.EXAMPLE
Set-RDWebClientDeploymentSetting SuppressTelemetry $true

Description
-----------
Disables telemetry gathering in the client
#>
function Set-RDWebClientDeploymentSetting
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    Param(
        [Parameter(mandatory=$true)]
        [string] $Name,
        [Parameter(mandatory=$true)]
        $Value
    )

    $context = GetModuleContext
    if (!(EnsureInitialized $context))
    {
        return
    }

    switch ($Name)
    {
        'SuppressTelemetry' {
            if ($Value -is [Boolean])
            {
                New-ItemProperty -Path $configKeyPath -Name $suppressTelemetryValueName -Value $Value -PropertyType DWORD -Force | Out-Null
                $context.DeploymentSettings[$Name] = $Value
                UpdateDeploymentSettingsFile $context
            }
            else
            {
                Write-Error 'This setting requires a value of type [Boolean].'
            }
        }
        default { Write-Error "Setting '$Name' does not exist." }
    }
}

<#
.SYNOPSIS
Gets the deployment settings for the Remote Desktop web client
.PARAMETER Name
Specifies the name of the setting to retrieve
.EXAMPLE
Get-RDWebClientDeploymentSetting

Description
-----------
Gets all deployment settings

.EXAMPLE
Get-RDWebClientDeploymentSetting SuppressTelemetry

Description
-----------
Gets the SuppressTelemetry deployment setting
#>
function Get-RDWebClientDeploymentSetting
{
    [CmdletBinding(SupportsShouldProcess=$true)]
    [OutputType([System.Collections.DictionaryEntry])]
    Param(
        [string] $Name
    )

    $context = GetModuleContext
    if (!(EnsureInitialized $context))
    {
        return
    }

    if ($Name)
    {
        if ($context.DeploymentSettings.ContainsKey($Name))
        {
            @{$Name = $context.DeploymentSettings[$Name]}.GetEnumerator()
        }
        else
        {
            Write-Error "Setting '$Name' does not exist."
            return
        }
    }
    else
    {
        $context.DeploymentSettings.GetEnumerator()
    }
}

# SIG # Begin signature block
# MIIdjgYJKoZIhvcNAQcCoIIdfzCCHXsCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUQu155Hr9kUXZmaOxIMr1iEjO
# Zv2gghhqMIIE2jCCA8KgAwIBAgITMwAAAQF4QskMs6jYswAAAAABATANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTgwODIzMjAyMDIx
# WhcNMTkxMTIzMjAyMDIxWjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# LTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEm
# MCQGA1UECxMdVGhhbGVzIFRTUyBFU046RTA0MS00QkVFLUZBN0UxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCbadtQJVLLJBRVaOm+saBSd4ZWqY5+RiSwRqn5bL2kIKit
# 3IaJnDDxJ/PhLOVEZbiA0GgHLkOZEn8CnBOpv0q0Au3JuVhKJzveWh/Zlt8WM+vY
# GlOgXiIzSv4iH9xFa+GgfuEhBZtZv8aWQET8/QXH0Z07rlflaRHw8v93r/SqoA63
# sGYXJh49kovbKY8/lLqq1ves7OeStSFssS7r2svjMWxXhpKgcA1fZmmMa/IyfT/2
# QEhya5LK04/PNZFSXS7Yfz0kP7cA17X41j25zHsDkdiFiULO00+uOhdvH1+slnQH
# Scz0tAQHoKiqYkdUNy37oxJjIeGHICB/zz6/X8T/AgMBAAGjggEJMIIBBTAdBgNV
# HQ4EFgQUgk5O3GQeGZVd8TZu73LWf4S95BkwHwYDVR0jBBgwFoAUIzT42VJGcArt
# QPt2+7MrsMM1sw8wVAYDVR0fBE0wSzBJoEegRYZDaHR0cDovL2NybC5taWNyb3Nv
# ZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljcm9zb2Z0VGltZVN0YW1wUENBLmNy
# bDBYBggrBgEFBQcBAQRMMEowSAYIKwYBBQUHMAKGPGh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2kvY2VydHMvTWljcm9zb2Z0VGltZVN0YW1wUENBLmNydDATBgNV
# HSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQUFAAOCAQEAPojiCg/OLTqboQdZ
# 1oZO1HabJrLJyQY6Ry+AQue5Fg7dmjEfuBYbARQ3yorUyU4OwlLbzbelhdZDOkWR
# RIALTP2Dq6TwRb2oOIMzXdHbr0Svxv4xgrcC5mu4MeoyMRl3b52llEFIxjIAP3sG
# 4wZE2oMLFuJsv3thspy8q5gP+65E32zYRwhrBtdgrJJ1fn9T4z3nMMCDzfkojAEe
# AtKPA1rcYUEdRa2sRICD/sEnk4kNL+HrLmW7ksog83O9Js2KHxET/pKy8yf6bayP
# JgttOKwk+HyFRWoILkGMcFXT1b3S2G8EfHKY7NCfoHgYNffyRXQnXg433YKBOmqj
# n/aRATCCBf8wggPnoAMCAQICEzMAAAEDXiUcmR+jHrgAAAAAAQMwDQYJKoZIhvcN
# AQELBQAwfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYG
# A1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMTAeFw0xODA3MTIy
# MDA4NDhaFw0xOTA3MjYyMDA4NDhaMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xHjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANGUdjbmhqs2/mn5RnyLiFDLkHB/
# sFWpJB1+OecFnw+se5eyznMK+9SbJFwWtTndG34zbBH8OybzmKpdU2uqw+wTuNLv
# z1d/zGXLr00uMrFWK040B4n+aSG9PkT73hKdhb98doZ9crF2m2HmimRMRs621TqM
# d5N3ZyGctloGXkeG9TzRCcoNPc2y6aFQeNGEiOIBPCL8r5YIzF2ZwO3rpVqYkvXI
# QE5qc6/e43R6019Gl7ziZyh3mazBDjEWjwAPAf5LXlQPysRlPwrjo0bb9iwDOhm+
# aAUWnOZ/NL+nh41lOSbJY9Tvxd29Jf79KPQ0hnmsKtVfMJE75BRq67HKBCMCAwEA
# AaOCAX4wggF6MB8GA1UdJQQYMBYGCisGAQQBgjdMCAEGCCsGAQUFBwMDMB0GA1Ud
# DgQWBBRHvsDL4aY//WXWOPIDXbevd/dA/zBQBgNVHREESTBHpEUwQzEpMCcGA1UE
# CxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xFjAUBgNVBAUTDTIz
# MDAxMis0Mzc5NjUwHwYDVR0jBBgwFoAUSG5k5VAF04KqFzc3IrVtqMp1ApUwVAYD
# VR0fBE0wSzBJoEegRYZDaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljQ29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNybDBhBggrBgEFBQcBAQRV
# MFMwUQYIKwYBBQUHMAKGRWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y2VydHMvTWljQ29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNydDAMBgNVHRMBAf8E
# AjAAMA0GCSqGSIb3DQEBCwUAA4ICAQCf9clTDT8NJuyiRNgN0Z9jlgZLPx5cxTOj
# pMNsrx/AAbrrZeyeMxAPp6xb1L2QYRfnMefDJrSs9SfTSJOGiP4SNZFkItFrLTuo
# LBWUKdI3luY1/wzOyAYWFp4kseI5+W4OeNgMG7YpYCd2NCSb3bmXdcsBO62CEhYi
# gIkVhLuYUCCwFyaGSa/OfUUVQzSWz4FcGCzUk/Jnq+JzyD2jzfwyHmAc6bAbMPss
# uwculoSTRShUXM2W/aDbgdi2MMpDsfNIwLJGHF1edipYn9Tu8vT6SEy1YYuwjEHp
# qridkPT/akIPuT7pDuyU/I2Au3jjI6d4W7JtH/lZwX220TnJeeCDHGAK2j2w0e02
# v0UH6Rs2buU9OwUDp9SnJRKP5najE7NFWkMxgtrYhK65sB919fYdfVERNyfotTWE
# cfdXqq76iXHJmNKeWmR2vozDfRVqkfEU9PLZNTG423L6tHXIiJtqv5hFx2ay1//O
# kpB15OvmhtLIG9snwFuVb0lvWF1pKt5TS/joynv2bBX5AxkPEYWqT5q/qlfdYMb1
# cSD0UaiayunR6zRHPXX6IuxVP2oZOWsQ6Vo/jvQjeDCy8qY4yzWNqphZJEC4Omek
# B1+g/tg7SRP7DOHtC22DUM7wfz7g2QjojCFKQcLe645b7gPDHW5u5lQ1ZmdyfBrq
# UvYixHI/rjCCBgcwggPvoAMCAQICCmEWaDQAAAAAABwwDQYJKoZIhvcNAQEFBQAw
# XzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29m
# dDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# MB4XDTA3MDQwMzEyNTMwOVoXDTIxMDQwMzEzMDMwOVowdzELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAn6Fssd/b
# SJIqfGsuGeG94uPFmVEjUK3O3RhOJA/u0afRTK10MCAR6wfVVJUVSZQbQpKumFww
# JtoAa+h7veyJBw/3DgSY8InMH8szJIed8vRnHCz8e+eIHernTqOhwSNTyo36Rc8J
# 0F6v0LBCBKL5pmyTZ9co3EZTsIbQ5ShGLieshk9VUgzkAyz7apCQMG6H81kwnfp+
# 1pez6CGXfvjSE/MIt1NtUrRFkJ9IAEpHZhEnKWaol+TTBoFKovmEpxFHFAmCn4Tt
# VXj+AZodUAiFABAwRu233iNGu8QtVJ+vHnhBMXfMm987g5OhYQK1HQ2x/PebsgHO
# IktU//kFw8IgCwIDAQABo4IBqzCCAacwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4E
# FgQUIzT42VJGcArtQPt2+7MrsMM1sw8wCwYDVR0PBAQDAgGGMBAGCSsGAQQBgjcV
# AQQDAgEAMIGYBgNVHSMEgZAwgY2AFA6sgmBAVieX5SUT/CrhClOVWeSkoWOkYTBf
# MRMwEQYKCZImiZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0
# MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHmC
# EHmtFqFKoKWtTHNY9AcTLmUwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQu
# Y3JsMFQGCCsGAQUFBwEBBEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraS9jZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwEwYDVR0l
# BAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQEFBQADggIBABCXisNcA0Q23em0rXfb
# znlRTQGxLnRxW20ME6vOvnuPuC7UEqKMbWK4VwLLTiATUJndekDiV7uvWJoc4R0B
# hqy7ePKL0Ow7Ae7ivo8KBciNSOLwUxXdT6uS5OeNatWAweaU8gYvhQPpkSokInD7
# 9vzkeJkuDfcH4nC8GE6djmsKcpW4oTmcZy3FUQ7qYlw/FpiLID/iBxoy+cwxSnYx
# PStyC8jqcD3/hQoT38IKYY7w17gX606Lf8U1K16jv+u8fQtCe9RTciHuMMq7eGVc
# WwEXChQO0toUmPU8uWZYsy0v5/mFhsxRVuidcJRsrDlM1PZ5v6oYemIp76KbKTQG
# dxpiyT0ebR+C8AvHLLvPQ7Pl+ex9teOkqHQ1uE7FcSMSJnYLPFKMcVpGQxS8s7Ow
# TWfIn0L/gHkhgJ4VMGboQhJeGsieIiHQQ+kr6bv0SMws1NgygEwmKkgkX1rqVu+m
# 3pmdyjpvvYEndAYR7nYhv5uCwSdUtrFqPYmhdmG0bqETpr+qR/ASb/2KMmyy/t9R
# yIwjyWa9nR2HEmQCPS2vWY+45CHltbDKY7R4VAXUQS5QrJSwpXirs6CWdRrZkocT
# dSIvMqgIbqBbjCW/oO+EyiHW6x5PyZruSeD3AWVviQt9yGnI5m7qp5fOMSn/DsVb
# XNhNG6HY+i+ePy5VFmvJE6P9MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCBI4wggSKAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAEDXiUcmR+jHrgAAAAAAQMwCQYFKw4DAhoFAKCB
# ojAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYK
# KwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUvnU6tEv5svNvD76kIy83QsNxkD0w
# QgYKKwYBBAGCNwIBDDE0MDKgFIASAE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQADh7sgX2EkBmNa
# Q+mJ+oJD+jEzAVju8tcyUsrn2II3LsTzkEAQdkYzwsoVjsQkuClRXjvyU0hCA2P1
# VauczBuOEwATUKxbwjM7+IeOuygXJmVgA+jJCbw7/VSzwLqT+UoUa3w5XbpcCSZV
# 7B2gFtAyWZuYaViHYBD6tPjF06Mb/0U2phc0SXMJoftHkkd22C/BlVJ/C5aYpoGT
# 3en5KBSfeyjdErgNXP9+nUP6hxpdFHVFAZBDCuZZdG7H4k06xSSXQrf1EbQBhe3w
# URFvGGevUW6cuCY1tOwczuGykI6fkI3iTs9I7lLxgCbY+nvgIXl7Ma8YnvShqbGj
# pHFYlEbKoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQQITMwAAAQF4QskMs6jYswAAAAABATAJBgUrDgMCGgUA
# oF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTgx
# MDI3MDAyODAxWjAjBgkqhkiG9w0BCQQxFgQUzs/w71bGiE/ubRjtB1OYITqJM/Iw
# DQYJKoZIhvcNAQEFBQAEggEAhfZozT4ZfiPhkLlOSUmsIKuNJj44oHlI9ZPgVMm4
# EQYqiEYXudecc07Tw0iRlZyyXleCNV2jPXgnxyZR90js0+RHUbWCLRKTXvUHdnZ/
# 34turBJYyhOZlTtuvZCbV1Y2qQjXD26FBdBtbL5N48SSOmtvIvLUAWplDMNl2jZt
# SxuX52ldXnAMPc1nFcYT4Ah8H160pm+iQGU28wM+KmkbutfvpFSKvju7UwfUtSFr
# /+m8DgNh60ev64JVNeEn008o7OX5aDNOi+82UBHTgHQZDigaMBMDuBUJpOLHZJs0
# i14jksWEGjZXi8HFy/S2b/tB/5vyoKWigW08s4+5DsYi9w==
# SIG # End signature block
